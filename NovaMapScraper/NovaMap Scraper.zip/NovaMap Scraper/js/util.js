function getQueryString(a) {
    a = new RegExp("(^|&)" + a + "=([^&]*)(&|$)", "i");
    a = window.location.search.substr(1).match(a);
    return null != a ? decodeURIComponent(a[2]) : null;
}
function setCookie(a, d, c) {
    var b = new Date();
    b.setTime(b.getTime() + 864e5 * c);
    c = "expires=" + b.toUTCString();
    document.cookie = a + "=" + d + ";" + c + ";path=/";
}
function getCookie(a) {
    a += "=";
    for (
        var d = decodeURIComponent(document.cookie).split(";"), c = 0;
        c < d.length;
        c++
    ) {
        for (var b = d[c]; " " == b.charAt(0); ) b = b.substring(1);
        if (0 == b.indexOf(a)) return b.substring(a.length, b.length);
    }
    return "";
}
function secureFetch(a, d) {
    a = "http://localhost" + a;
    return new Promise((c, b) => {
        d.mode = "cors";
        fetch(a, d)
            .then((e) => {
                if (e.ok) c(e);
                else {
                    switch (e.status) {
                        case 403:
                            console.log("forbidden: " + a),
                                setCookie("username", "", -1),
                                alert("por favor inicia sesión primero."),
                                window.location.assign("/login.html");
                    }
                    b(e);
                }
            })
            .catch((e) => {
                console.log(e);
                b(e);
            });
    });
}
function newTabulator(a, d) {
    d.ajaxRequestFunc = function (c, b, e) {
        return new Promise(function (g, h) {
            console.log("secureFetch: " + c);
            secureFetch(c, b)
                .then((f) => f.json())
                .then((f) => {
                    g(f);
                })
                .catch((f) => {
                    h(f);
                });
        });
    };
    return new Tabulator(a, d);
}
