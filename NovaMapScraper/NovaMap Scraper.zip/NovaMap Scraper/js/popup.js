function normalizeProfileId(a) {
    return a.trim().toLowerCase();
}

document.querySelectorAll(".tab-btn").forEach((btn) => {
    btn.addEventListener("click", function () {
        const tabName = this.dataset.tab;

        document
            .querySelectorAll(".tab-btn")
            .forEach((b) => b.classList.remove("active"));
        this.classList.add("active");

        document
            .querySelectorAll(".tab-content")
            .forEach((c) => c.classList.remove("active"));
        document.getElementById(`tab-${tabName}`).classList.add("active");
    });
});

document
    .getElementById("addprofilebtn")
    .addEventListener("click", async function () {
        var a = normalizeProfileId(document.getElementById("profileid").value);

        await History.add(a);
        await loadHistory();

        Toast.info("Abriendo Google Maps...");

        window.open(
            "https://www.google.com/maps/search/" + encodeURIComponent(a)
        );
    });

async function loadSettings() {
    const settings = await Settings.load();

    document.getElementById("extractionLimit").value = settings.extractionLimit;
    document.getElementById("limitValue").textContent =
        settings.extractionLimit;
    document.getElementById("extractionSpeed").value = settings.extractionSpeed;
    document.getElementById("stealthMode").checked = settings.stealthMode;
    document.getElementById("exportTemplate").value = settings.exportTemplate;
}

document
    .getElementById("extractionLimit")
    .addEventListener("input", function () {
        document.getElementById("limitValue").textContent = this.value;
    });

document
    .getElementById("saveSettings")
    .addEventListener("click", async function () {
        const settings = {
            extractionLimit: parseInt(
                document.getElementById("extractionLimit").value
            ),
            extractionSpeed: document.getElementById("extractionSpeed").value,
            stealthMode: document.getElementById("stealthMode").checked,
            exportTemplate: document.getElementById("exportTemplate").value,
        };

        await Settings.save(settings);
        Toast.success("Configuración guardada correctamente");
    });

async function loadHistory() {
    const history = await History.get();
    const listEl = document.getElementById("historyList");

    if (history.length === 0) {
        listEl.innerHTML =
            '<p class="empty-state">No hay búsquedas recientes</p>';
        return;
    }

    listEl.innerHTML = history
        .map(
            (item) => `
        <div class="history-item" data-term="${item.term}">
            <div class="history-term">${item.term}</div>
            <div class="history-date">${History.formatDate(
                item.timestamp
            )}</div>
        </div>
    `
        )
        .join("");

    document.querySelectorAll(".history-item").forEach((item) => {
        item.addEventListener("click", function () {
            const term = this.dataset.term;
            document.getElementById("profileid").value = term;

            document.querySelector('.tab-btn[data-tab="home"]').click();

            Toast.info("Búsqueda cargada");
        });
    });
}

document
    .getElementById("clearHistory")
    .addEventListener("click", async function () {
        await History.clear();
        await loadHistory();
        Toast.success("Historial limpiado");
    });

const modal = document.getElementById("supportModal");
const btn = document.getElementById("supportBtn");
const span = document.getElementById("closeModal");

if (btn) {
    btn.onclick = function () {
        modal.classList.remove("hidden");
    };
}

if (span) {
    span.onclick = function () {
        modal.classList.add("hidden");
    };
}

window.onclick = function (event) {
    if (event.target == modal) {
        modal.classList.add("hidden");
    }
};

document.addEventListener("DOMContentLoaded", async function () {
    await loadSettings();
    await loadHistory();
});
