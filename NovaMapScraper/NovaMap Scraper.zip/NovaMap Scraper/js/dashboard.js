function capitalizeFirstLetter(a) {
    return a.charAt(0).toUpperCase() + a.slice(1);
}
var table = newTabulator("#example-table", {
    layout: "fitData",
    placeholder: "Cargando",
    selectable: 1,
});
document
    .getElementById("download-csv")
    .addEventListener("click", async function () {
        const rawData = table.getData();
        const data = await applyExportTemplate(rawData);

        const searchTerm = await getSearchTerm();
        const filename = searchTerm
            ? `${searchTerm}_results.csv`
            : "results.csv";
        table.download("csv", filename, {}, data);
        console.log(`download ${data.length} emails.`);
    });
document
    .getElementById("download-xlsx")
    .addEventListener("click", async function () {
        const rawData = table.getData();
        const data = await applyExportTemplate(rawData);

        const searchTerm = await getSearchTerm();
        const filename = searchTerm
            ? `${searchTerm}_results.xlsx`
            : "results.xlsx";
        table.download(
            "xlsx",
            filename,
            {
                sheetName: "Mis Datos",
            },
            data
        );
        console.log(`download ${data.length} emails.`);
    });
function flattenObject(a, c = "") {
    const d = {};
    for (const [b, e] of Object.entries(a))
        (a = c ? `${c}_${b}` : b),
            "object" === typeof e && null !== e
                ? Object.assign(d, flattenObject(e, a))
                : (d[a] = e);
    return d;
}

async function getSearchTerm() {
    try {
        const result = await chrome.storage.local.get("currentSearchTerm");
        if (result.currentSearchTerm) {
            return result.currentSearchTerm
                .replace(/[^a-z0-9]/gi, "_")
                .toLowerCase()
                .substring(0, 50);
        }
    } catch (e) {
        console.error("Error getting search term:", e);
    }
    return null;
}

async function applyExportTemplate(data) {
    const settings = await chrome.storage.sync.get("settings");
    const template = settings.settings?.exportTemplate || "all";

    if (template === "all") return data;

    const templates = {
        basic: ["name", "phone", "email", "website"],
        contact: ["name", "phone", "email"],
        business: ["name", "address", "category", "averageRating"],
    };

    const fields = templates[template];
    if (!fields) return data;

    return data.map((item) => {
        const filtered = {};
        fields.forEach((field) => {
            if (item[field] !== undefined) {
                filtered[field] = item[field];
            }
        });
        return filtered;
    });
}
function generateColumns(a) {
    const translationMap = {
        name: "Nombre",
        phone: "Teléfono",
        email: "Correo",
        website: "Sitio Web",
        address: "Dirección",
        instagram: "Instagram",
        facebook: "Facebook",
        twitter: "Twitter",
        linkedin: "Linkedin",
        yelp: "Yelp",
        youtube: "Youtube",
        placeID: "ID del Lugar",
        cID: "CID",
        category: "Categoría",
        reviewCount: "Reseñas",
        averageRating: "Calificación",
        latitude: "Latitud",
        longitude: "Longitud",
    };
    const c = new Set(
        "name phone email website address instagram facebook twitter linkedin yelp youtube placeID cID category reviewCount averageRating latitude longitude".split(
            " "
        )
    );
    var d = [];
    c.forEach((b) => {
        d.push({
            title: translationMap[b] || capitalizeFirstLetter(b),
            field: b,
            width: 300,
            resizable: !0,
        });
    });
    Array.from(a)
        .sort()
        .forEach((b) => {
            c.has(b) ||
                d.push({
                    title: translationMap[b] || capitalizeFirstLetter(b),
                    field: b,
                    width: 300,
                    resizable: !0,
                });
        });
    table.setColumns(d);
}
function showData() {
    chrome.storage.local.get(null, function (a) {
        a = a.leads || [];
        for (var c = new Set(), d = [], b = 0; b < a.length; ++b) {
            const e = flattenObject(a[b]);
            d.push(e);
            Object.keys(e).forEach((f) => c.add(f));
        }
        generateColumns(c);
        table.setData(d);
    });
}
function normalizeProfileId(a) {
    return a.replace("@", "").trim().toLowerCase();
}
$(document).ready(function () {
    showData();
});
