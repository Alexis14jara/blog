const Settings = {
    defaults: {
        extractionLimit: 100,
        extractionSpeed: "normal",
        stealthMode: true,
        exportTemplate: "all",
    },

    async load() {
        const result = await chrome.storage.sync.get("settings");
        return result.settings || this.defaults;
    },

    async save(settings) {
        await chrome.storage.sync.set({ settings });
    },

    async get(key) {
        const settings = await this.load();
        return settings[key];
    },

    async set(key, value) {
        const settings = await this.load();
        settings[key] = value;
        await this.save(settings);
    },

    getSpeedConfig(speed) {
        const configs = {
            slow: { min: 3000, max: 5000 },
            normal: { min: 1000, max: 3000 },
            fast: { min: 500, max: 1500 },
        };
        return configs[speed] || configs.normal;
    },
};
