const CCTLDS = new Set(
        "ac ad ae af ag ai al am an ao aq ar as at au aw ax az ba bb bd be bf bg bh bi bj bm bn bo br bs bt bv bw by bz ca cc cd cf cg ch ci ck cl cm cn co cr cu cv cw cx cy cz de dj dk dm do dz ec ee eg eh er es et eu fi fj fk fm fo fr ga gb gd ge gf gg gh gi gl gm gn gp gq gr gs gt gu gw gy hk hm hn hr ht hu id ie il im in io iq ir is it je jm jo jp ke kg kh ki km kn kp kr kw ky kz la lb lc li lk lr ls lt lu lv ly ma mc md me mf mg mh mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nc ne nf ng ni nl no np nr nu nz om pa pe pf pg ph pk pl pm pn pr ps pt pw py qa re ro rs ru rw sa sb sc sd se sg sh si sj sk sl sm sn so sr ss st su sv sx sy sz tc td tf tg th tj tk tl tm tn to tr tt tv tw tz ua ug uk us uy uz va vc ve vg vi vn vu wf ws xk ye yt za zm zw".split(
            " "
        )
    ),
    BLACKLISTED_PATHS = new Set(
        "/reel /about /tr /privacy /download /pg /settings /vp /profiles".split(
            " "
        )
    ),
    SOCIAL_MEDIA_PLATFORMS = {
        instagram:
            /(((http|https):\/\/)?((www\.)?(?:instagram.com|instagr.am)\/([A-Za-z0-9_.]{2,30})))/gi,
        facebook:
            /(?:https?:)?\/\/(?:www\.)?(?:facebook|fb)\.com\/((?![A-z]+\.php)(?!marketplace|gaming|watch|me|messages|help|search|groups)[A-z0-9_\-\.]+)\/?/gi,
        youtube:
            /(?:https?:)?\/\/(?:[A-z]+\.)?youtube\.com\/(channel\/([A-z0-9-_]+)|user\/([A-z0-9]+))\/?/gi,
        linkedin:
            /(?:https?:)?\/\/(?:[\w]+\.)?linkedin\.com\/((company|school)\/[A-z0-9-\u00c0-\u00ff\.]+|in\/[\w\-_\u00c0-\u00ff%]+)\/?/gi,
        twitter:
            /(?:(?:http|https):\/\/)?(?:www.)?(?:twitter\.com|x\.com)\/(?!(oauth|account|tos|privacy|signup|home|hashtag|search|login|widgets|i|settings|start|share|intent|oct)(['"\?\.\/]|$))([A-Za-z0-9_]{1,15})/gim,
        email: /\b[A-Z0-9._%+-]{1,64}@(?!-)(?:[A-Z0-9-]+\.)+[A-Z]{2,63}\b/gi,
    },
    CONTACT_PAGE_PATHS =
        "/contact /contact-us /contact-me /about /about-me /about-us /team /our-team /meet-the-team /support /customer-service /feedback /help /sales /return /location /faq".split(
            " "
        ),
    EMAIL_BLACKLIST = new Set(
        ".png .jpg .jpeg .gif .webp wixpress.com sentry.io noreply abuse no-reply subscribe mailer-daemon domain.com email.com yourname wix.com".split(
            " "
        )
    ),
    SOCIAL_MEDIA_DOMAINS = new Set([
        "instagram",
        "facebook",
        "youtube",
        "linkedin",
        "twitter",
    ]);
function getTimestamp() {
    return `[${new Date().toISOString()}]`;
}
function decode_cf_email(a) {
    let c = "";
    const g = parseInt(a.slice(0, 2), 16);
    for (let d = 2; a.length - d; d += 2) {
        const h = parseInt(a.slice(d, d + 2), 16) ^ g;
        c += String.fromCharCode(h);
    }
    return c;
}
function get_domain(a) {
    a = new URL(a).host.toLowerCase().split(".");
    return 3 <= a.length && CCTLDS.has(a[a.length - 1])
        ? a[a.length - 3]
        : 2 <= a.length
        ? a[a.length - 2]
        : a[0];
}
function normalize_social_link(a) {
    try {
        a.startsWith("//") && (a = "https:" + a);
        a.startsWith("http") || (a = "https://" + a);
        const c = new URL(a);
        if ("http:" === c.protocol || "" === c.protocol) c.protocol = "https:";
        "instagram.com" === c.host && (c.host = "www.instagram.com");
        "facebook.com" === c.host && (c.host = "www.facebook.com");
        "yelp.com" === c.host && (c.host = "www.yelp.com");
        "www.twitter.com" === c.host && (c.host = "twitter.com");
        "www.x.com" === c.host && (c.host = "x.com");
        "/" === c.pathname[c.pathname.length - 1] &&
            (c.pathname = c.pathname.slice(0, -1));
        return BLACKLISTED_PATHS.has(c.pathname) ? "" : c.toString();
    } catch (c) {
        console.warn(getTimestamp(), "normalize_social_link error: ", a, c);
    }
    return "";
}
async function fetchUrlContent(a, c = 1e4) {
    const g = new AbortController();
    c = setTimeout(() => g.abort(), c);
    try {
        console.log(getTimestamp(), "begin to visit url: ", a);
        const d = await fetch(a, { signal: g.signal, redirect: "follow" });
        console.log(
            getTimestamp(),
            `end to visit ${a}, ok: ${d.ok}, status: ${d.status}`
        );
        return d.ok
            ? await d.text()
            : (console.warn(
                  getTimestamp(),
                  "visit error: ",
                  a,
                  " status: ",
                  d.status
              ),
              "");
    } catch (d) {
        return (
            console.warn(
                getTimestamp(),
                "fetch error for ",
                a,
                "AbortError" === d.name ? "timeout" : d.message
            ),
            ""
        );
    } finally {
        clearTimeout(c);
    }
}
async function extractemail(a, c, g) {
    try {
        a.startsWith("//") && (a = "https:" + a);
        a.startsWith("http") || (a = "https://" + a);
        const n = await fetchUrlContent(a);
        if (!n || "string" !== typeof n || 10 > n.length)
            return (
                console.warn(getTimestamp(), "visit error: ", a),
                {
                    instagram: new Set(),
                    facebook: new Set(),
                    youtube: new Set(),
                    linkedin: new Set(),
                    twitter: new Set(),
                    email: new Set(),
                }
            );
        var d = n.normalize("NFKC"),
            h = new Set();
        let k = {};
        for (const b in SOCIAL_MEDIA_PLATFORMS) {
            k[b] = new Set();
            const e = d.match(SOCIAL_MEDIA_PLATFORMS[b]);
            e &&
                e.forEach((f) => {
                    f &&
                        ("email" === b
                            ? k[b].add(f)
                            : (f = normalize_social_link(f)) && k[b].add(f));
                });
        }
        let r;
        try {
            r = new URL(a);
        } catch (b) {
            return (
                console.warn(getTimestamp(), "Invalid URL format: ", a, b), k
            );
        }
        c = [];
        try {
            var l = d.match(/data-cfemail="([a-f0-9]+)"/i);
            l && l[1] && k.email.add(decode_cf_email(l[1]));
            l = /<a[^>]+href=["']([^"']+)["']/gi;
            let b;
            for (; null !== (b = l.exec(d)); )
                try {
                    const e = b[1];
                    e && c.push(new URL(e, r).toString());
                } catch (e) {}
        } catch (b) {
            console.warn(getTimestamp(), "Link extraction error: ", a, b);
        }
        for (const b of c)
            try {
                const e = new URL(b).pathname.toLowerCase();
                CONTACT_PAGE_PATHS.some((f) => e.includes(f)) && h.add(b);
            } catch (e) {}
        for (var m of c)
            try {
                const b = new URL(m).host.toLowerCase();
                for (const e of SOCIAL_MEDIA_DOMAINS)
                    if (
                        ((d = !1),
                        (d =
                            "twitter" === e
                                ? "twitter.com" === b ||
                                  "www.twitter.com" === b ||
                                  b.endsWith(".twitter.com") ||
                                  "x.com" === b ||
                                  "www.x.com" === b ||
                                  b.endsWith(".x.com")
                                : b === `${e}.com` ||
                                  b === `www.${e}.com` ||
                                  b.endsWith(`.${e}.com`)))
                    ) {
                        const f = normalize_social_link(m);
                        f && k[e].add(f);
                        break;
                    }
            } catch (b) {}
        if (g && 0 < h.size) {
            g = [...h];
            h = [];
            for (m = 0; m < g.length; m += 10) {
                const b = g
                        .slice(m, m + 10)
                        .map((f) => extractemail(f, "", !1)),
                    e = await Promise.all(b);
                h.push(...e);
            }
            h.forEach((b) => {
                if (b)
                    for (const e in b)
                        b[e] &&
                            "function" === typeof b[e].forEach &&
                            b[e].forEach((f) => {
                                k[e].add(f);
                            });
            });
        }
        const t = new Set(),
            q = new Set();
        let p;
        try {
            p = get_domain(a);
        } catch (b) {
            console.warn(getTimestamp(), "get_domain error: ", a, b),
                (p = null);
        }
        k.email.forEach((b) => {
            const e = b.replace("u003e", "").toLowerCase();
            Array.from(EMAIL_BLACKLIST).some((f) => e.includes(f)) ||
                (t.add(e), p && e.includes(p) && q.add(e));
        });
        k.email = 0 < q.size ? q : t;
        return k;
    } catch (n) {
        return (
            console.warn(getTimestamp(), `visit url error: ${a}`, n),
            {
                instagram: new Set(),
                facebook: new Set(),
                youtube: new Set(),
                linkedin: new Set(),
                twitter: new Set(),
                email: new Set(),
            }
        );
    }
}
chrome.runtime.onMessage.addListener(async function (a, c, g) {
    if ("openPage" === a.action) {
        if (a.searchTerm) {
            await chrome.storage.local.set({ currentSearchTerm: a.searchTerm });
        }
        await chrome.storage.local.set({ leads: a.data });
        chrome.tabs.create({ url: "dashboard.html" });
        return false;
    } else if ("openReviewPage" === a.action) {
        await chrome.storage.local.set({ leads: a.data });
        chrome.tabs.create({ url: "reviews.html" });
        return false;
    } else if ("access" === a.action) {
        const d = await fetchUrlContent(a.data.url);
        g(d);
        return true;
    } else if ("email" === a.action) {
        var d = a.data;
        d = await extractemail(d.website, d.name, d.deep_search);
        const h = {};
        for (const l in d) h[l] = Array.from(d[l]);
        g(h);
        return true;
    }
    return false;
});
