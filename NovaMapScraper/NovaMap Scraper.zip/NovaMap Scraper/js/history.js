const History = {
    maxItems: 10,

    async add(searchTerm) {
        const history = await this.get();
        const newEntry = {
            term: searchTerm,
            timestamp: Date.now(),
        };

        const filtered = history.filter((item) => item.term !== searchTerm);

        filtered.unshift(newEntry);

        const trimmed = filtered.slice(0, this.maxItems);

        await chrome.storage.local.set({ searchHistory: trimmed });
        return trimmed;
    },

    async get() {
        const result = await chrome.storage.local.get("searchHistory");
        return result.searchHistory || [];
    },

    async clear() {
        await chrome.storage.local.remove("searchHistory");
    },

    formatDate(timestamp) {
        const date = new Date(timestamp);
        const now = new Date();
        const diff = now - date;

        if (diff < 60000) return "Hace un momento";
        if (diff < 3600000) return `Hace ${Math.floor(diff / 60000)} min`;
        if (diff < 86400000) return `Hace ${Math.floor(diff / 3600000)} h`;
        return date.toLocaleDateString("es-ES");
    },
};
