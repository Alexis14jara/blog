try {
    importScripts("js/mybg.js");
} catch (a) {
    console.error(a);
}
