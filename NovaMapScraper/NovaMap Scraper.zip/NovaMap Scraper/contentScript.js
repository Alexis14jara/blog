var auto_extract_flag = !1,
    leads = [],
    leads_lnglat = new Set(),
    collect_email = !0;
(() => {
    var a = document.createElement("div");
    a.className = "extension_gms_page";
    var e = document.createElement("div");
    e.id = "extension_gms_leads_info";
    e.className = "leads-header";
    e.innerHTML =
        '<img src="' +
        chrome.runtime.getURL("icons/logo.png") +
        '" class="injected-logo" alt="Logo"><span class="leads-count">Clientes: 0</span>';
    const f = document.createElement("button");
    f.className = "extension_gms_button";
    f.innerText = "Iniciar Auto Extracción";
    f.id = "extension_gms_start_btn";
    f.addEventListener("click", async (d) => {
        d = d.target;
        if (auto_extract_flag) {
            d.innerText = "Iniciar Auto Extracción";
            d.style = "";
            auto_extract_flag = !1;
            console.log("Auto extracción detenida!");
        } else {
            d.innerText = "Detener Auto Extracción";
            d.style.backgroundColor = "#ea4335";
            d.style.color = "#fff";
            auto_extract_flag = !0;

            progressBar.style.display = "block";

            const settings = await chrome.storage.sync.get("settings");
            const extractionLimit = settings.settings?.extractionLimit || 100;
            const extractionSpeed =
                settings.settings?.extractionSpeed || "normal";
            const stealthMode = settings.settings?.stealthMode !== false;

            console.log(
                `Iniciando extracción (Límite: ${extractionLimit}, Velocidad: ${extractionSpeed}, Sigiloso: ${stealthMode})`
            );

            var h = document.querySelector('[role="search"] button');
            h
                ? (h.click(), await new Promise((n) => setTimeout(n, 3e3)))
                : console.error("Botón de búsqueda no encontrado");
            if ((h = document.querySelector('[role="feed"]'))) {
                for (var p = 0, q = -1; auto_extract_flag; ) {
                    console.log("Paginando...");
                    h.scrollTop = h.scrollHeight;

                    let delay;
                    if (extractionSpeed === "slow") {
                        delay = stealthMode
                            ? 3000 + Math.random() * 2000
                            : 4000;
                    } else if (extractionSpeed === "fast") {
                        delay = stealthMode ? 500 + Math.random() * 1000 : 1000;
                    } else {
                        delay = stealthMode
                            ? 1000 + Math.random() * 2000
                            : 2000;
                    }

                    await new Promise((m) => setTimeout(m, delay));

                    if (leads.length >= extractionLimit) {
                        console.log(
                            `Límite de extracción alcanzado: ${extractionLimit}`
                        );
                        break;
                    }

                    if (document.querySelector(".HlvSq")) {
                        console.log("No hay más resultados.");
                        break;
                    }
                    if (q === h.scrollHeight) {
                        if ((p++, 20 < p)) {
                            console.log("Lista inalterada por 20 iteraciones.");
                            break;
                        }
                    } else (p = 0), (q = h.scrollHeight);
                    console.log(
                        `Stall: ${p}, ScrollTop: ${h.scrollTop}, ScrollHeight: ${h.scrollHeight}, Leads: ${leads.length}/${extractionLimit}`
                    );
                }
                d.innerText = "Iniciar Auto Extracción";
                d.style = "";
                auto_extract_flag = !1;
                progressBar.style.display = "none";
                console.log(
                    `Auto extracción finalizada! Total: ${leads.length} clientes`
                );
            } else
                console.error("Lista de resultados no encontrada"),
                    (d.innerText = "Iniciar Auto Extracción"),
                    (d.style = ""),
                    (auto_extract_flag = !1);
        }
    });
    const g = document.createElement("button");
    g.className = "extension_gms_button";
    g.innerText = "Exportar Clientes (0)";
    g.id = "extension_gms_download_btn";
    g.addEventListener("click", async () => {
        const searchInput = document.querySelector('[role="search"] input');
        const searchTerm = searchInput ? searchInput.value : null;

        chrome.runtime.sendMessage({
            action: "openPage",
            data: leads,
            searchTerm: searchTerm,
        });
        console.log("leads: ", leads);
    });
    const k = document.createElement("button");
    k.className = "extension_gms_button";
    k.innerText = "Limpiar";
    k.id = "extension_gms_clear_btn";
    k.addEventListener("click", async () => {
        window.leads = [];
        window.leads_lnglat.clear();
        e.innerHTML =
            '<img src="' +
            chrome.runtime.getURL("icons/logo.png") +
            '" class="injected-logo" alt="Logo"><span class="leads-count">Clientes: 0</span>';
        g.innerText = "Exportar Clientes (0)";
    });
    const progressBar = document.createElement("div");
    progressBar.className = "extraction-progress";
    progressBar.innerHTML =
        '<div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div><div class="progress-text" id="progressText">0%</div>';
    progressBar.style.display = "none";

    a.appendChild(e);
    a.appendChild(progressBar);
    a.appendChild(f);
    a.appendChild(g);
    a.appendChild(k);
    setInterval(() => {
        const d = document.getElementsByClassName("w6VYqd")[0];
        d &&
            !d.contains(a) &&
            (d.appendChild(a), console.log("Botón insertado exitosamente"));
    }, 2e3);
})();
function decode_cf_email(a) {
    s = "";
    r = parseInt(a.substr(0, 2), 16);
    for (j = 2; a.length - j; j += 2)
        (c = parseInt(a.substr(j, 2), 16) ^ r), (s += String.fromCharCode(c));
    return s;
}
function get_domain(a) {
    const e = new Set(
        "ac ad ae af ag ai al am an ao aq ar as at au aw ax az ba bb bd be bf bg bh bi bj bm bn bo br bs bt bv bw by bz ca cc cd cf cg ch ci ck cl cm cn co cr cu cv cw cx cy cz de dj dk dm do dz ec ee eg eh er es et eu fi fj fk fm fo fr ga gb gd ge gf gg gh gi gl gm gn gp gq gr gs gt gu gw gy hk hm hn hr ht hu id ie il im in io iq ir is it je jm jo jp ke kg kh ki km kn kp kr kw ky kz la lb lc li lk lr ls lt lu lv ly ma mc md me mf mg mh mk ml mm mn mo mp mq mr ms mt mu mv mw mx my mz na nc ne nf ng ni nl no np nr nu nz om pa pe pf pg ph pk pl pm pn pr ps pt pw py qa re ro rs ru rw sa sb sc sd se sg sh si sj sk sl sm sn so sr ss st su sv sx sy sz tc td tf tg th tj tk tl tm tn to tr tt tv tw tz ua ug uk us uy uz va vc ve vg vi vn vu wf ws xk ye yt za zm zw".split(
            " "
        )
    );
    a = new URL(a).host.toLowerCase().split(".");
    return e.has(a[a.length - 1]) ? a[a.length - 3] : a[a.length - 2];
}
function normalize_social_link(a) {
    try {
        a.startsWith("//") && (a = "https:" + a);
        a.startsWith("http") || (a = "https://" + a);
        const e = new Set(
            "/reel /about /tr /privacy /download /pg /settings /vp /profiles".split(
                " "
            )
        );
        let f = new URL(a);
        if ("http:" === f.protocol || "" === f.protocol) f.protocol = "https:";
        "instagram.com" === f.host && (f.host = "www.instagram.com");
        "facebook.com" === f.host && (f.host = "www.facebook.com");
        "yelp.com" === f.host && (f.host = "www.yelp.com");
        "www.twitter.com" === f.host && (f.host = "twitter.com");
        "/" === f.pathname[f.pathname.length - 1] &&
            (f.pathname = f.pathname.slice(0, -1));
        return e.has(f.pathname) ? "" : f.toString();
    } catch (e) {
        console.warn("normalize_social_link error: ", a, e);
    }
    return "";
}
async function extractemail(a, e, f) {
    try {
        a.startsWith("//") && (a = "https:" + a);
        a.startsWith("http") || (a = "https://" + a);
        const t = await chrome.runtime.sendMessage({
            action: "access",
            data: { url: a },
        });
        if (10 > t.length) console.warn("visit error: ", a);
        else {
            var g = t.normalize("NFKC");
            e = {
                instagram:
                    /(((http|https):\/\/)?((www\.)?(?:instagram.com|instagr.am)\/([A-Za-z0-9_.]{2,30})))/gi,
                facebook:
                    /(?:https?:)?\/\/(?:www\.)?(?:facebook|fb)\.com\/((?![A-z]+\.php)(?!marketplace|gaming|watch|me|messages|help|search|groups)[A-z0-9_\-\.]+)\/?/gi,
                youtube:
                    /(?:https?:)?\/\/(?:[A-z]+\.)?youtube\.com\/(channel\/([A-z0-9-_]+)|user\/([A-z0-9]+))\/?/gi,
                linkedin:
                    /(?:https?:)?\/\/(?:[\w]+\.)?linkedin\.com\/((company|school)\/[A-z0-9-\u00c0-\u00ff\.]+|in\/[\w\-_\u00c0-\u00ff%]+)\/?/gi,
                twitter:
                    /(?:(?:http|https):\/\/)?(?:www.)?(?:twitter.com)\/(?!(oauth|account|tos|privacy|signup|home|hashtag|search|login|widgets|i|settings|start|share|intent|oct)(['"\?\.\/]|$))([A-Za-z0-9_]{1,15})/gim,
                email: /\b[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}\b/gi,
                yelp: /https?:\/\/(www\.)?yelp\.com\/biz\/[a-zA-Z0-9_-]+/gi,
            };
            var k = new Set(),
                d = {};
            for (const b in e) {
                d[b] = new Set();
                var h = g.match(e[b]);
                h &&
                    h.forEach((l) => {
                        l &&
                            ("email" === b
                                ? d[b].add(l)
                                : (l = normalize_social_link(l)) &&
                                  d[b].add(l));
                    });
            }
            var p = new URL(a);
            try {
                var q = new DOMParser()
                    .parseFromString(g, "text/html")
                    .querySelector(".__cf_email__");
                if (q) {
                    const b = q.getAttribute("data-cfemail");
                    b && d.email.add(decode_cf_email(b));
                }
            } catch (b) {
                console.warn("DOMParser parsed error: ", a, b);
            }
            q = /<a\s+(?:[^>]*?\s+)?href=(["'])(.*?)\1/gi;
            h = [];
            for (var n; (n = q.exec(g)); ) h.push(new URL(n[2], p).toString());
            g =
                "/contact /contact-us /contact-me /about /about-me /about-us /team /our-team /meet-the-team /support /customer-service /feedback /help /sales privacy return location policy faq".split(
                    " "
                );
            for (p = 0; p < h.length; p++) {
                var m = h[p];
                for (n = 0; n < g.length; ++n)
                    if (m.includes(g[n])) {
                        k.add(m);
                        break;
                    }
            }
            for (m = 0; m < h.length; m++)
                try {
                    const b = h[m];
                    if (!b) continue;
                    const l = new URL(b).host.toLowerCase();
                    for (const u in e)
                        if (l.includes(u)) {
                            if (0 >= d[u].size) {
                                const v = normalize_social_link(b);
                                v && d[u].add(v);
                            }
                            break;
                        }
                } catch (b) {
                    console.warn(`error: ${h[m]}`, b);
                }
            if (f && 0 < k.size) {
                const b = [...k].map(
                    async (l) => await extractemail(l, "", !1)
                );
                (await Promise.all(b)).map((l) => {
                    if (l)
                        for (const u in l)
                            l[u].forEach((v) => {
                                d[u].add(v);
                            });
                });
            }
            console.log("Email for : ", a, d, [...k].join());
            var w = new Set(),
                x = new Set(),
                y =
                    ".png .jpg .jpeg .gif .webp wixpress.com sentry.io noreply abuse no-reply subscribe mailer-daemon domain.com email.com yourname wix.com".split(
                        " "
                    ),
                z = get_domain(a);
            d.email.forEach((b) => {
                b = b.replace("u003e", "").toLowerCase();
                for (let l = 0; l < y.length; ++l) if (b.includes(y[l])) return;
                w.add(b);
                z && b.includes(z) && x.add(b);
            });
            d.email = 0 < x.size ? x : w;
            return d;
        }
    } catch (t) {
        console.log(`visit url error: ${a}`, t);
    }
}
async function findemails(a) {
    const e = new URL(a);
    var f = [];
    "/contact /contact-us /contact-me /about /about-me /about-us /team /our-team /meet-the-team /support /customer-service /feedback /help /sales"
        .split(" ")
        .map((g) => {
            f.push(new URL(g, e).toString());
        });
    a = f.map(async (g) => await extractemail(g, ""));
    return (await Promise.all(a)).filter((g) => g && "" !== g.trim()).join(",");
}
window.addEventListener("message", async function (a) {
    if (a.data && "search" === a.data.type && a.data.data) {
        a = JSON.parse(a.data.data.replace('/*""*/', ""));
        results = JSON.parse(a.d.slice(5));
        feed = results[64];
        a = [];
        for (let k = 0; k < feed.length; ++k)
            try {
                var e = feed[k][feed[k].length - 1],
                    f = e[11] || "";
                if (!f) continue;
                let d = "";
                try {
                    d = e[7][0];
                } catch (b) {}
                let h = "";
                try {
                    h = e[178][0][0];
                } catch (b) {}
                let p = "";
                try {
                    p = e[4][8];
                } catch (b) {}
                let q = "";
                try {
                    q = e[4][7];
                } catch (b) {}
                let n = "";
                try {
                    n = e[13].join(";");
                } catch (b) {}
                let m = "";
                try {
                    m = e[78];
                } catch (b) {}
                let w = "";
                try {
                    w = e[37][0][0][29][1];
                } catch (b) {}
                let x = (e[2] || []).join(","),
                    y = "",
                    z = "";
                try {
                    (y = e[9][2]), (z = e[9][3]);
                } catch (b) {}
                let t = [];
                try {
                    if (e[203] && e[203][0]) {
                        const b = e[203][0];
                        for (var g = 0; g < b.length; g++) {
                            const l = b[g][0],
                                u = (b[g][3] || []).map((v) => v[0]).join(", ");
                            t.push({ day: l, hours: u, weekDay: b[g][1] });
                        }
                    } else {
                        console.log(
                            "No working hours available for this business"
                        );
                    }
                } catch (b) {
                    console.warn("Error processing working hours:", b);
                }
                t.sort((b, l) => b.weekDay - l.weekDay);
                g = {};
                for (const b of t) g[`${b.weekDay}_${b.day}`] = b.hours;
                leads_lnglat.has(m) ||
                    (leads_lnglat.add(m),
                    a.push({
                        name: f,
                        phone: h,
                        website: d,
                        address: x,
                        email: "",
                        placeID: m,
                        cID: w,
                        category: n,
                        reviewCount: p,
                        averageRating: q,
                        latitude: y,
                        longitude: z,
                        ...g,
                    }));
            } catch (d) {
                console.warn("Error processing item:", d);
            }
        e = a.map(async (k) => {
            try {
                if (k.website && collect_email) {
                    const d = await chrome.runtime.sendMessage({
                        action: "email",
                        data: {
                            website: k.website,
                            name: k.name,
                            deep_search: !0,
                        },
                    });
                    if (d) for (const h in d) k[h] = [...d[h]].join();
                }
            } catch (d) {
                console.warn("collect email error: ", k);
            }
            return k;
        });
        e = await Promise.all(e);
        for (f = 0; f < e.length; ++f) leads.push(e[f]);
        console.log(leads);

        const settings = await chrome.storage.sync.get("settings");
        const extractionLimit = settings.settings?.extractionLimit || 100;
        const progress = Math.min((leads.length / extractionLimit) * 100, 100);
        const progressFill = document.getElementById("progressFill");
        const progressText = document.getElementById("progressText");
        if (progressFill) progressFill.style.width = progress + "%";
        if (progressText) progressText.textContent = Math.floor(progress) + "%";

        document.getElementById(
            "extension_gms_download_btn"
        ).innerText = `Exportar Clientes (${leads.length})`;
        document.getElementById(
            "extension_gms_leads_info"
        ).innerHTML = `<img src="${chrome.runtime.getURL(
            "icons/logo.png"
        )}" class="injected-logo" alt="Logo"><span class="leads-count">Clientes: ${
            leads.length
        }</span>`;
    }
});
