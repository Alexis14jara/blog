let campaignState = {
  isRunning: false,
  isPaused: false,
  queue: [],
  message: "",
  stats: { sent: 0, failed: 0, pending: 0, total: 0 },
  settings: { minDelay: 5, maxDelay: 15 },
  results: [],
  startTime: null,
  countdown: 0,
};

let messageSafetyTimeout = null;
let isPageReadyForCurrentContact = false;

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  switch (request.action) {
    case "START_CAMPAIGN":
      startCampaign(request.payload);
      sendResponse({ status: "started" });
      break;
    case "PAUSE_CAMPAIGN":
      pauseCampaign();
      sendResponse({ status: "paused" });
      break;
    case "RESUME_CAMPAIGN":
      resumeCampaign();
      sendResponse({ status: "resumed" });
      break;
    case "STOP_CAMPAIGN":
      stopCampaign();
      sendResponse({ status: "stopped" });
      break;
    case "GET_STATUS":
      sendResponse(campaignState);
      break;
    case "MSG_RESULT":
      handleMessageResult(request.result);
      sendResponse({ status: "ack" });
      break;
  }
  return true;
});

function startCampaign(payload) {
  if (campaignState.isRunning) return;

  // Reset State
  campaignState = {
    isRunning: true,
    isPaused: false,
    queue: [...payload.contacts],
    message: payload.message,
    stats: {
      sent: 0,
      failed: 0,
      pending: payload.contacts.length,
      total: payload.contacts.length,
    },
    settings: payload.settings,
    results: [],
    startTime: Date.now(),
    countdown: 0,
  };

  console.log("[NovaFlow] Campaña iniciada.", campaignState.settings);
  broadcastStats();
  processNext();
}

function pauseCampaign() {
  if (campaignState.isRunning) {
    campaignState.isRunning = false;
    campaignState.isPaused = true;
    console.log("[NovaFlow] Campaña PAUSADA");
    broadcastStats();
    clearSafetyTimeout();
  }
}

function resumeCampaign() {
  if (campaignState.isPaused) {
    campaignState.isRunning = true;
    campaignState.isPaused = false;
    console.log("[NovaFlow] Campaña REANUDADA");
    broadcastStats();
    processNext();
  }
}

function stopCampaign() {
  console.log("[NovaFlow] Campaña PARADA");
  campaignState.isRunning = false;
  campaignState.isPaused = false;
  campaignState.queue = [];
  campaignState.countdown = 0;

  clearSafetyTimeout();
  finishCampaign(true);
}

function processNext() {
  if (!campaignState.isRunning || campaignState.queue.length === 0) {
    if (!campaignState.isPaused) finishCampaign();
    return;
  }

  const nextContact = campaignState.queue[0];
  isPageReadyForCurrentContact = false;

  // 1. Navegar INMEDIATAMENTE
  executeNavigation(nextContact).then(() => {
    const min = parseInt(campaignState.settings.minDelay);
    const max = parseInt(campaignState.settings.maxDelay);
    const delaySec = Math.floor(Math.random() * (max - min + 1) + min);

    campaignState.countdown = delaySec;
    console.log(`[NovaFlow] Navegando a ${nextContact}. Espera: ${delaySec}s`);

    runCountdown(nextContact);
  });
}

function runCountdown(contact) {
  if (!campaignState.isRunning) return;

  if (campaignState.countdown <= 0) {
    attemptSendWhenReady(contact);
    return;
  }

  chrome.runtime
    .sendMessage({
      action: "UPDATE_COUNTDOWN",
      seconds: campaignState.countdown,
    })
    .catch(() => {});

  campaignState.countdown--;
  setTimeout(() => runCountdown(contact), 1000);
}

async function attemptSendWhenReady(contact) {
  if (!campaignState.isRunning) return;

  if (isPageReadyForCurrentContact) {
    console.log(
      `[NovaFlow] Tiempo cumplido y página lista. Enviando a ${contact}...`
    );
    const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    if (tabs[0]) {
      triggerSendAction(tabs[0].id, contact);
    }
  } else {
    console.log(
      `[NovaFlow] Tiempo cumplido pero página cargando. Esperando carga para ${contact}...`
    );
  }
}

async function executeNavigation(contact) {
  try {
    const tabs = await chrome.tabs.query({ url: "https://web.whatsapp.com/*" });
    if (tabs.length === 0) {
      console.error("WhatsApp Web no encontrado");
      campaignState.isRunning = false;
      return;
    }

    const tabId = tabs[0].id;
    const msgEncoded = encodeURIComponent(campaignState.message);
    const targetUrl = `https://web.whatsapp.com/send?phone=${contact}&text=${msgEncoded}`;

    await chrome.tabs.update(tabId, { url: targetUrl, active: true });

    setSafetyTimeout(contact);
    monitorTabLoad(tabId, contact);
  } catch (e) {
    console.error("Error navegación", e);
    handleMessageResult({ status: "failed", phone: contact, error: e.message });
  }
}

function monitorTabLoad(tabId, contact) {
  const listener = (tid, changeInfo, tab) => {
    if (tid === tabId && changeInfo.status === "complete") {
      chrome.tabs.onUpdated.removeListener(listener);
      console.log(`[NovaFlow] Carga navegador completa ${contact}.`);

      isPageReadyForCurrentContact = true;

      if (campaignState.countdown <= 0 && campaignState.isRunning) {
        console.log(
          `[NovaFlow] Timer finalizado previa carga. Disparando rápido.`
        );
        setTimeout(() => triggerSendAction(tabId, contact), 2000);
      }
    }
  };
  chrome.tabs.onUpdated.addListener(listener);
}

async function triggerSendAction(tabId, contact) {
  if (!campaignState.isRunning) return;

  try {
    await chrome.scripting.executeScript({
      target: { tabId: tabId },
      files: ["assets/js/app.js"],
    });

    chrome.tabs.sendMessage(tabId, {
      action: "CLICK_SEND_BUTTON",
      phone: contact,
    });
  } catch (e) {
    // Manejo silencioso de error de Frame destruido (Race Condition por recarga)
    if (
      e.message.includes("Frame with ID 0 was removed") ||
      e.message.includes("tab was closed")
    ) {
      console.warn(
        `[NovaFlow] Race condition detectada para ${contact}. El Safety Timeout lo reintentará/fallará.`
      );
      // No hacemos nada, dejamos que el Safety Timeout actúe si es necesario
      return;
    }

    console.error("Script Injection Error", e);
    handleMessageResult({
      status: "failed",
      phone: contact,
      error: "Injection Failed",
    });
  }
}

function handleMessageResult(result) {
  clearSafetyTimeout();
  console.log("[NovaFlow] Resultado recibido:", result);

  if (!campaignState.isRunning && !campaignState.isPaused) return;
  if (campaignState.queue.length > 0 && campaignState.queue[0] !== result.phone)
    return;

  recordResultAndAdvance(result);
}

function setSafetyTimeout(contact) {
  clearSafetyTimeout();
  messageSafetyTimeout = setTimeout(() => {
    console.warn(`[NovaFlow] SAFETY TIMEOUT: ${contact}. Forzando siguiente.`);
    handleMessageResult({
      status: "failed",
      phone: contact,
      reason: "TIMEOUT_SAFETY_GENERIC",
    });
  }, 45000);
}

function clearSafetyTimeout() {
  if (messageSafetyTimeout) {
    clearTimeout(messageSafetyTimeout);
    messageSafetyTimeout = null;
  }
}

function recordResultAndAdvance(result) {
  campaignState.results.push({
    phone: result.phone,
    status: result.status,
    error: result.reason || null,
    time: new Date().toLocaleTimeString(),
  });

  if (campaignState.queue.length > 0) {
    campaignState.queue.shift();

    if (result.status === "ok") campaignState.stats.sent++;
    else campaignState.stats.failed++;

    campaignState.stats.pending = campaignState.queue.length;

    broadcastStats();
    if (campaignState.isRunning) processNext();
  }
}

function broadcastStats() {
  chrome.runtime
    .sendMessage({
      action: "UPDATE_STATS",
      stats: campaignState.stats,
      isRunning: campaignState.isRunning,
      isPaused: campaignState.isPaused,
    })
    .catch(() => {});
}

async function finishCampaign(wasStopped = false) {
  console.log("[NovaFlow] Fin de campaña");
  campaignState.isRunning = false;
  campaignState.isPaused = false;
  campaignState.countdown = 0;
  clearSafetyTimeout();

  broadcastStats();

  const historyItem = {
    id: campaignState.startTime,
    date: new Date(campaignState.startTime).toLocaleString(),
    message: campaignState.message,
    total: campaignState.stats.total,
    sent: campaignState.stats.sent,
    failed: campaignState.stats.failed,
    details: campaignState.results,
    status: wasStopped ? "Stopped" : "Completed",
  };

  const data = await chrome.storage.local.get("history");
  const history = data.history || [];
  history.unshift(historyItem);
  if (history.length > 50) history.pop();

  await chrome.storage.local.set({ history });

  chrome.runtime
    .sendMessage({
      action: "CAMPAIGN_FINISHED",
      id: historyItem.id,
      wasStopped: wasStopped,
    })
    .catch(() => {});
}
