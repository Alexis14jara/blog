document.addEventListener("DOMContentLoaded", async () => {
  // --- Elements ---
  const tabs = document.querySelectorAll(".nav-btn");
  const contents = document.querySelectorAll(".tab-content");

  // Buttons
  const startBtn = document.getElementById("start-btn");
  const pauseBtn = document.getElementById("pause-btn");
  const stopBtn = document.getElementById("stop-btn");
  const resumeBtn = document.getElementById("resume-btn");

  const messageInput = document.getElementById("message");
  const contactsInput = document.getElementById("contacts");

  // Stats
  const statSent = document.getElementById("stat-sent");
  const statPending = document.getElementById("stat-pending");
  const statFailed = document.getElementById("stat-failed");

  // Settings
  const minDelayInput = document.getElementById("min-delay");
  const maxDelayInput = document.getElementById("max-delay");
  const limitInput = document.getElementById("limit");
  const limitDisplay = document.getElementById("limit-setting");
  const timeEstimateDisplay = document.getElementById("time-estimate");

  // Header Actions
  document.getElementById("btn-pro").addEventListener("click", () => {
    alert("La versión Pro esta en desarrollo");
    // window.open("https://novaflow.app/pro", "_blank");
  });

  const helpWrapper = document.querySelector(".help-wrapper");
  const helpTooltip = document.getElementById("help-tooltip");

  helpWrapper.addEventListener("mouseenter", () => {
    helpTooltip.classList.add("active");
  });
  helpWrapper.addEventListener("mouseleave", () => {
    helpTooltip.classList.remove("active");
  });

  document.getElementById("btn-support").addEventListener("click", () => {
    window.open("https://wa.me/595992489510", "_blank"); // Placeholder Support
  });

  // Modal Elements
  const modalOverlay = document.getElementById("custom-modal");
  const modalIcon = document.getElementById("modal-icon");
  const modalTitle = document.getElementById("modal-title");
  const modalMessage = document.getElementById("modal-message");
  const modalConfirmBtn = document.getElementById("modal-confirm");
  const modalCancelBtn = document.getElementById("modal-cancel");

  // --- Modal Logic ---
  function showModal(title, message, icon = "⚠️", isConfirm = false) {
    return new Promise((resolve) => {
      modalTitle.innerText = title;
      modalMessage.innerText = message;
      modalIcon.innerText = icon;

      modalConfirmBtn.onclick = () => {
        closeModal();
        resolve(true);
      };

      if (isConfirm) {
        modalCancelBtn.style.display = "block";
        modalCancelBtn.onclick = () => {
          closeModal();
          resolve(false);
        };
      } else {
        modalCancelBtn.style.display = "none";
      }

      modalOverlay.classList.add("active");
    });
  }

  function closeModal() {
    modalOverlay.classList.remove("active");
  }

  // --- Button Management ---
  function updateButtonState(isRunning, isPaused) {
    // Ocultar todos primero
    startBtn.style.display = "none";
    pauseBtn.style.display = "none";
    resumeBtn.style.display = "none";
    stopBtn.style.display = "none";

    if (!isRunning && !isPaused) {
      // Estado Inicial (o Stop/Finish)
      startBtn.style.display = "flex";
      startBtn.disabled = false;
      startBtn.innerHTML = `<span>Iniciar Campaña</span>
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                        <path d="M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z"></path>
                    </svg>`;
    } else if (isRunning && !isPaused) {
      // Corriendo
      pauseBtn.style.display = "flex";
      stopBtn.style.display = "flex";
    } else if (!isRunning && isPaused) {
      // Pausado
      resumeBtn.style.display = "flex";
      stopBtn.style.display = "flex";
    }
  }

  if (limitDisplay) {
    limitInput.addEventListener(
      "input",
      (e) => (limitDisplay.value = e.target.value)
    );
  }

  // --- Time Estimation Logic ---
  function updateEstimation() {
    const text = contactsInput.value;
    const count = text.split(/[\n,]/).filter((s) => s.trim().length > 5).length;

    if (count === 0) {
      timeEstimateDisplay.innerText = "--:--";
      return;
    }

    const min = parseInt(minDelayInput.value) || 5;
    const max = parseInt(maxDelayInput.value) || 15;
    const avg = (min + max) / 2;
    const totalSeconds = count * (avg + 6); // +6s overhead actualizado

    const minutes = Math.floor(totalSeconds / 60);
    const seconds = Math.floor(totalSeconds % 60);

    timeEstimateDisplay.innerText = `~${minutes}m ${seconds}s`;
  }

  contactsInput.addEventListener("input", updateEstimation);
  minDelayInput.addEventListener("input", updateEstimation);
  maxDelayInput.addEventListener("input", updateEstimation);

  // --- Tab Logic ---
  tabs.forEach((tab) => {
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      contents.forEach((c) => c.classList.remove("active"));
      tab.classList.add("active");
      const targetId = tab.getAttribute("data-tab");
      const content = document.getElementById(targetId);
      if (content) content.classList.add("active");
      if (targetId === "history") loadHistory();
    });
  });

  // --- ACTIONS ---
  startBtn.addEventListener("click", async () => {
    const message = messageInput.value.trim();
    const contactsRaw = contactsInput.value.trim();
    let minDelay = parseInt(minDelayInput.value, 10);
    let maxDelay = parseInt(maxDelayInput.value, 10);
    const limit = parseInt(limitInput.value, 10);

    if (!message) {
      showModal("Faltan datos", "El campo de mensaje está vacío.", "✍️");
      return;
    }
    if (!contactsRaw) {
      showModal("Faltan datos", "La lista de contactos está vacía.", "📋");
      return;
    }

    const rawList = contactsRaw
      .split(/[\n,;]+/)
      .map((s) => s.trim())
      .filter(Boolean);
    const validContacts = [];
    rawList.forEach((c) => {
      let clean = c.replace(/\D/g, "");
      if (clean.length >= 10) validContacts.push(clean);
    });

    if (validContacts.length === 0) {
      showModal("Error", "No se encontraron números válidos", "🚫");
      return;
    }

    if (minDelay > maxDelay) {
      const temp = minDelay;
      minDelay = maxDelay;
      maxDelay = temp;
      minDelayInput.value = minDelay;
      maxDelayInput.value = maxDelay;
    }

    if (validContacts.length > limit) {
      const confirmTruncate = await showModal(
        "Límite Excedido",
        `Se enviarán solo los primeros ${limit}. ¿Continuar?`,
        "✂️",
        true
      );
      if (!confirmTruncate) return;
      validContacts.length = limit;
    }

    updateButtonState(true, false); // Corriendo

    chrome.runtime.sendMessage({
      action: "START_CAMPAIGN",
      payload: {
        contacts: validContacts,
        message: message,
        settings: { minDelay, maxDelay, limit },
      },
    });
  });

  pauseBtn.addEventListener("click", () => {
    updateButtonState(false, true); // Pausado
    chrome.runtime.sendMessage({ action: "PAUSE_CAMPAIGN" });
  });

  resumeBtn.addEventListener("click", () => {
    updateButtonState(true, false); // Corriendo
    chrome.runtime.sendMessage({ action: "RESUME_CAMPAIGN" });
  });

  stopBtn.addEventListener("click", async () => {
    const confirmStop = await showModal(
      "¿Parar campaña?",
      "Se detendrá el envío y se guardará el progreso actual.",
      "🛑",
      true
    );
    if (confirmStop) {
      chrome.runtime.sendMessage({ action: "STOP_CAMPAIGN" });
      updateButtonState(false, false);
    }
  });

  // --- Background Listeners ---
  chrome.runtime.onMessage.addListener(
    async (request, sender, sendResponse) => {
      if (request.action === "UPDATE_STATS") {
        updateStatsUI(request.stats);
        if (request.hasOwnProperty("isRunning")) {
          // Sincronizar botones en caso de reapertura
          updateButtonState(request.isRunning, request.isPaused);
        }
      } else if (request.action === "UPDATE_COUNTDOWN") {
        // Opcional: mostrar countdown en algun lado, tal vez en el botón Pause
        if (pauseBtn.style.display !== "none") {
          pauseBtn.innerHTML = `<span>Pausar (${request.seconds}s)</span> <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg>`;
        }
      } else if (request.action === "CAMPAIGN_FINISHED") {
        updateButtonState(false, false);

        if (!request.wasStopped) {
          const seeReport = await showModal(
            "¡Finalizado!",
            "¿Ver reporte detallado?",
            "🎉",
            true
          );
          if (seeReport) openReport(request.id);
        }
        loadHistory();
      }
    }
  );

  // Init Check
  chrome.runtime.sendMessage({ action: "GET_STATUS" }, (response) => {
    if (response) {
      updateStatsUI(response.stats);
      updateButtonState(response.isRunning, response.isPaused);
    }
  });

  function updateStatsUI(stats) {
    statSent.innerText = stats.sent;
    statPending.innerText = stats.pending;
    statFailed.innerText = stats.failed;
  }

  // --- History Logic ---
  function openReport(campaignId) {
    chrome.tabs.create({ url: `report.html?id=${campaignId}` });
  }

  async function loadHistory() {
    const data = await chrome.storage.local.get("history");
    const history = data.history || [];
    const listContainer = document.getElementById("history-list");
    listContainer.innerHTML = "";

    if (history.length === 0) {
      listContainer.innerHTML =
        '<div style="text-align:center; color: var(--text-muted); padding: 20px;">No hay campañas guardadas</div>';
      return;
    }

    history.forEach((item) => {
      const el = document.createElement("div");
      el.className = "history-item";
      el.innerHTML = `
                <div class="history-info">
                    <h4>${item.date}</h4>
                    <span class="status-badge finished">Enviados: ${item.sent}/${item.total}</span>
                </div>
                <div class="history-actions">
                    <button class="icon-btn view-btn" title="Ver Reporte">📄</button>
                    <button class="icon-btn edit-btn" title="Reutilizar">✏️</button>
                    <button class="icon-btn del-btn" title="Eliminar">🗑️</button>
                </div>
            `;
      el.querySelector(".view-btn").addEventListener("click", () =>
        openReport(item.id)
      );
      el.querySelector(".edit-btn").addEventListener("click", () =>
        loadCampaignIntoForm(item)
      );
      el.querySelector(".del-btn").addEventListener("click", () =>
        deleteHistoryItem(item.id)
      );
      listContainer.appendChild(el);
    });
  }

  async function loadCampaignIntoForm(item) {
    tabs[0].click();
    messageInput.value = item.message;
    await showModal(
      "Datos Restaurados",
      "Ingresa nuevamente los contactos.",
      "✏️"
    );
  }

  async function deleteHistoryItem(id) {
    const confirmDel = await showModal(
      "¿Eliminar?",
      "Se borrará del historial.",
      "🗑️",
      true
    );
    if (!confirmDel) return;

    const data = await chrome.storage.local.get("history");
    let history = data.history || [];
    history = history.filter((h) => h.id !== id);
    await chrome.storage.local.set({ history });
    loadHistory();
  }
});
